package com.example.finestfabric;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public abstract class conform extends AppCompatActivity implements View.OnClickListener {
    TextView textView9;
    EditText editTextTextPersonName, editTextPhone, editTextTextEmailAddress2, editTextTextPassword;
    Button button8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conform);
        textView9 = findViewById(R.id.textView9);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextTextPersonName = findViewById(R.id.editTextTextPersonName);
        editTextTextEmailAddress2 = findViewById(R.id.editTextTextEmailAddress2);
        editTextTextPassword = findViewById(R.id.editTextTextPassword);
        button8 = findViewById(R.id.button8);

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(conform.this, cardbag.class);
                startActivity(intent);
            }
        });



            }
        }

