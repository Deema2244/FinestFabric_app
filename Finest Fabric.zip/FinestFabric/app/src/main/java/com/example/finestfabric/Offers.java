package com.example.finestfabric;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Offers extends AppCompatActivity {
    ImageButton imageButton, imageButton2,imageButton5 = findViewById(R.id.imageButton5);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offers);
        imageButton=findViewById(R.id.imageButton);
        imageButton2=findViewById(R.id.imageButton2);
        imageButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Offers.this, cardbag.class);
                startActivity(intent);
                imageButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Offers.this, cardbag.class);
                        startActivity(intent);
                        imageButton2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent intent = new Intent(Offers.this, cardbag.class);
                                startActivity(intent);
                            }
                        });
                    }
                });
            }
        });

    }
}