package com.example.finestfabric;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class chooswhat extends AppCompatActivity {
    ImageButton imageButton8, imageButton20,imageButton4,imageButton3,imageButton7,imageButton2;
    TextView textView10;
    EditText editTextTextEmailAddress;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chooswhat);
        imageButton8 = findViewById(R.id.imageButton8);
        imageButton20 = findViewById(R.id.imageButton20);
        imageButton4 =findViewById(R.id.imageButton4);
        imageButton3 = findViewById(R.id.imageButton3);
        imageButton7 = findViewById(R.id.imageButton7);
        imageButton2 = findViewById(R.id.imageButton2);
        textView10 = findViewById(R.id.textView10);
        editTextTextEmailAddress = findViewById(R.id.editTextTextEmailAddress);


        imageButton2.setOnClickListener(view -> {
            Intent intent = new Intent(chooswhat.this, Offers.class);
            startActivity(intent);
        });
        imageButton7.setOnClickListener(view -> {
            Intent intent = new Intent(chooswhat.this, conform.class);
            startActivity(intent);
        });
        imageButton3.setOnClickListener(view -> {
            Intent intent = new Intent(chooswhat.this, your.class);
            startActivity(intent);
        });
        imageButton4.setOnClickListener(view -> {
            Intent intent = new Intent(chooswhat.this, TypeOfFabric.class);
            startActivity(intent);
        });


        imageButton8.setOnClickListener(view -> {
            Intent intent = new Intent(chooswhat.this, cardbag.class);
            startActivity(intent);

            imageButton20.setOnClickListener(view1 -> {
                Intent intent1 = new Intent(chooswhat.this, cardbag.class);
                startActivity(intent1);

            });
        });

    }
}









